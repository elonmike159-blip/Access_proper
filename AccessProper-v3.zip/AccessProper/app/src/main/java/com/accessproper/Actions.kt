package com.accessproper

import android.content.Context

enum class Act(val id: String, val label: String) {
    SCROLL_DOWN("scroll_down", "Scroll down"),
    SCROLL_UP("scroll_up", "Scroll up"),
    BACK("back", "Back"),
    HOME("home", "Home"),
    RECENTS("recents", "Recent apps"),
    NOTIFICATIONS("notifications", "Notifications"),
    ASSISTANT("assistant", "Open search / assistant"),
    TAP("tap", "Tap screen centre"),
    MEDIA("media", "Play / Pause media"),
    DIALER("dialer", "Open phone dialer"),
    LOCK("lock", "Lock screen"),
    SCREENSHOT("screenshot", "Screenshot"),
    OPEN_APP("app", "Open an app…"),
    NONE("none", "Do nothing");

    companion object {
        fun byId(id: String): Act = values().firstOrNull { it.id == id } ?: NONE
    }
}

/** Which action each pulse count (1..4) triggers. Stored in SharedPreferences. */
object ActionMap {
    const val MAX = 4
    private val defaults = arrayOf(Act.SCROLL_DOWN, Act.ASSISTANT, Act.BACK, Act.HOME)
    private fun p(c: Context) = c.applicationContext.getSharedPreferences("ap", Context.MODE_PRIVATE)

    fun get(c: Context, pulses: Int): Act =
        Act.byId(p(c).getString("map_$pulses", defaults[pulses - 1].id) ?: "none")

    fun appPackage(c: Context, pulses: Int): String? = p(c).getString("app_$pulses", null)

    fun label(c: Context, pulses: Int): String {
        val a = get(c, pulses)
        return if (a == Act.OPEN_APP) "Open " + (p(c).getString("applabel_$pulses", "app") ?: "app") else a.label
    }

    fun set(c: Context, pulses: Int, act: Act, pkg: String? = null, appLabel: String? = null) {
        p(c).edit()
            .putString("map_$pulses", act.id)
            .putString("app_$pulses", pkg)
            .putString("applabel_$pulses", appLabel)
            .apply()
    }
}
