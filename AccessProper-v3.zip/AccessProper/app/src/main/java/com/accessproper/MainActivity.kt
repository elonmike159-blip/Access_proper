package com.accessproper

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity(), AccessState.Listener {

    private lateinit var orb: OrbView
    private lateinit var statusDot: View
    private lateinit var statusText: TextView
    private lateinit var gestureText: TextView
    private lateinit var errorText: TextView
    private lateinit var btnToggle: Button
    private lateinit var micState: TextView
    private lateinit var accState: TextView
    private lateinit var batState: TextView
    private lateinit var levelBar: ProgressBar
    private lateinit var sensBar: SeekBar
    private lateinit var sensText: TextView
    private lateinit var mapContainer: LinearLayout
    private lateinit var modeChips: List<TextView>
    private lateinit var micChips: List<TextView>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AccessState.load(this)
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        setContentView(R.layout.activity_main)

        orb = findViewById(R.id.orb)
        statusDot = findViewById(R.id.statusDot)
        statusText = findViewById(R.id.statusText)
        gestureText = findViewById(R.id.gestureText)
        errorText = findViewById(R.id.errorText)
        btnToggle = findViewById(R.id.btnToggle)
        micState = findViewById(R.id.micState)
        accState = findViewById(R.id.accState)
        batState = findViewById(R.id.batState)
        levelBar = findViewById(R.id.levelBar)
        sensBar = findViewById(R.id.sensBar)
        sensText = findViewById(R.id.sensText)
        mapContainer = findViewById(R.id.mapContainer)
        modeChips = listOf(R.id.chipChest, R.id.chipTap, R.id.chipMixed).map { findViewById<TextView>(it) }
        micChips = listOf(R.id.micAuto, R.id.micRaw, R.id.micVoice, R.id.micStd).map { findViewById<TextView>(it) }

        findViewById<View>(R.id.tileMic).setOnClickListener { requestPerms() }
        findViewById<View>(R.id.tileAcc).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<View>(R.id.tileBat).setOnClickListener { askBattery() }
        btnToggle.setOnClickListener { toggle() }
        findViewById<Button>(R.id.btnCalibrate).setOnClickListener {
            AccessState.recalibrate = true
            Toast.makeText(this, "Calibrating… 2 second shaant rahein", Toast.LENGTH_SHORT).show()
        }

        modeChips.forEachIndexed { i, v ->
            v.setOnClickListener { AccessState.saveMode(this, i); markChips() }
        }
        micChips.forEachIndexed { i, v ->
            v.setOnClickListener { AccessState.saveMic(this, i); markChips() }
        }

        val saved = AccessState.sensProgress(this)
        sensBar.progress = saved
        sensText.text = "Sensitivity: $saved%  (zyada = halka touch bhi pakre)"
        sensBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                AccessState.saveSens(this@MainActivity, p)
                sensText.text = "Sensitivity: $p%  (zyada = halka touch bhi pakre)"
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })

        markChips()
        renderRows()
    }

    override fun onResume() {
        super.onResume()
        AccessState.listener = this
        refresh()
    }

    override fun onPause() {
        AccessState.listener = null
        super.onPause()
    }

    // ---- permissions / setup ----

    private fun hasMic() =
        checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun accessibilityOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return s.contains(packageName) && s.contains("AccessProperService")
    }

    private fun batteryOk(): Boolean =
        (getSystemService(POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)

    private fun requestPerms() {
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
        requestPermissions(perms.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        refresh()
    }

    private fun askBattery() {
        if (batteryOk()) {
            Toast.makeText(this, "Battery already Unrestricted hai", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    .setData(Uri.parse("package:$packageName"))
            )
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }

    private fun toggle() {
        if (AccessState.running) {
            stopService(Intent(this, AudioEngineService::class.java))
        } else if (!hasMic()) {
            requestPerms()
        } else {
            startForegroundService(Intent(this, AudioEngineService::class.java))
        }
    }

    private fun setTile(tv: TextView, ok: Boolean) {
        tv.text = if (ok) "✓ Ready" else "Tap to set"
        tv.setTextColor(if (ok) Color.parseColor("#00E676") else Color.parseColor("#B8CDB0"))
    }

    private fun refresh() {
        setTile(micState, hasMic())
        setTile(accState, accessibilityOn())
        setTile(batState, batteryOk())
        onRunning(AccessState.running)
        onError(AccessState.error)
    }

    private fun markChips() {
        modeChips.forEachIndexed { i, v -> v.isSelected = (i == AccessState.mode) }
        micChips.forEachIndexed { i, v -> v.isSelected = (i == AccessState.micChoice) }
    }

    // ---- my signals ----

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun renderRows() {
        mapContainer.removeAllViews()
        for (p in 1..ActionMap.MAX) {
            val tv = TextView(this)
            tv.text = (if (p == 1) "1 pulse" else "$p pulses") + "   →   " + ActionMap.label(this, p) + "   ›"
            tv.setTextColor(Color.WHITE)
            tv.textSize = 15f
            tv.setPadding(dp(16), dp(14), dp(16), dp(14))
            tv.setBackgroundResource(R.drawable.glass_tile)
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(10)
            tv.layoutParams = lp
            tv.setOnClickListener { showPicker(p) }
            tv.setOnLongClickListener { testPulse(p); true }
            mapContainer.addView(tv)
        }
    }

    private fun testPulse(p: Int) {
        val s = AccessProperService.instance
        if (s == null) {
            Toast.makeText(this, "Pehle Accessibility ON karein", Toast.LENGTH_SHORT).show()
        } else {
            s.perform(p)
            orb.pulse()
        }
    }

    private fun showPicker(p: Int) {
        val acts = Act.values()
        val names = acts.map { it.label }.toTypedArray()
        val cur = acts.indexOf(ActionMap.get(this, p))
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle(if (p == 1) "1 pulse" else "$p pulses")
            .setSingleChoiceItems(names, cur) { d, which ->
                d.dismiss()
                if (acts[which] == Act.OPEN_APP) pickApp(p) else {
                    ActionMap.set(this, p, acts[which])
                    renderRows()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun pickApp(p: Int) {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = packageManager.queryIntentActivities(intent, 0)
            .sortedBy { it.loadLabel(packageManager).toString().lowercase() }
        val names = apps.map { it.loadLabel(packageManager).toString() }.toTypedArray()
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Kaunsi app kholni hai?")
            .setItems(names) { _, i ->
                ActionMap.set(this, p, Act.OPEN_APP, apps[i].activityInfo.packageName, names[i])
                renderRows()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---- AccessState.Listener ----

    override fun onRunning(running: Boolean) {
        val color = if (running) Color.parseColor("#00E676") else Color.parseColor("#FF1744")
        statusDot.backgroundTintList = ColorStateList.valueOf(color)
        statusText.text = if (running) "ACTIVE · ONLINE" else "STANDBY · OFFLINE"
        btnToggle.text = if (running) "Stop Background Daemon" else "Start Background Daemon  →"
        orb.setActive(running)
    }

    override fun onLevel(level: Float) {
        orb.setLevel(level)
        levelBar.progress = (level * 100).toInt()
    }

    override fun onGesture(count: Int) {
        orb.pulse()
        gestureText.text = (if (count == 1) "1 pulse" else "$count pulses") + " → " + ActionMap.label(this, count) +
            if (AccessProperService.instance == null) "\n(Accessibility ON karein!)" else ""
    }

    override fun onError(message: String?) {
        errorText.visibility = if (message == null) View.GONE else View.VISIBLE
        errorText.text = message ?: ""
    }
}
