package com.accessproper

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AudioEffect
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.Process
import android.os.SystemClock
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Sticky foreground service that owns the microphone and runs the pulse engine.
 */
class AudioEngineService : Service() {
    private var engine: PulseEngine? = null
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        if (!startInForeground()) { stopSelf(); return START_NOT_STICKY }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            AccessState.setError("Microphone permission nahi hai")
            stopSelf(); return START_NOT_STICKY
        }
        if (engine != null) return START_STICKY

        AccessState.load(this)
        wakeLock = (getSystemService(POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AccessProper:audio").apply { acquire() }
        engine = PulseEngine(applicationContext).also { it.start() }
        AccessState.setError(null)
        AccessState.setRunning(true)
        return START_STICKY
    }

    private fun startInForeground(): Boolean {
        return try {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "AccessProper listening", NotificationManager.IMPORTANCE_LOW)
            )
            val open = PendingIntent.getActivity(
                this, 0, Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val stop = PendingIntent.getService(
                this, 1, Intent(this, AudioEngineService::class.java).setAction(ACTION_STOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("AccessProper is active")
                .setContentText("Listening for pulses")
                .setContentIntent(open)
                .addAction(android.R.drawable.ic_media_pause, "Stop", stop)
                .setOngoing(true)
                .build()
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(ID, n)
            }
            true
        } catch (e: Exception) {
            AccessState.setError("Service start nahi hui: " + (e.message ?: "unknown"))
            false
        }
    }

    override fun onDestroy() {
        engine?.stop(); engine = null
        wakeLock?.let { if (it.isHeld) it.release() }
        AccessState.setRunning(false)
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.accessproper.STOP"
        private const val CHANNEL = "accessproper_listen"
        private const val ID = 1001
    }
}

// ---------------------------------------------------------------------------------------------

private class Biquad(b0: Double, b1: Double, b2: Double, a0: Double, a1: Double, a2: Double) {
    private val nb0 = (b0 / a0).toFloat(); private val nb1 = (b1 / a0).toFloat()
    private val nb2 = (b2 / a0).toFloat(); private val na1 = (a1 / a0).toFloat()
    private val na2 = (a2 / a0).toFloat()
    private var x1 = 0f; private var x2 = 0f; private var y1 = 0f; private var y2 = 0f

    fun process(x: Float): Float {
        val y = nb0 * x + nb1 * x1 + nb2 * x2 - na1 * y1 - na2 * y2
        x2 = x1; x1 = x; y2 = y1; y1 = y
        return y
    }

    companion object {
        fun lowPass(fc: Double, fs: Double): Biquad {
            val w = 2 * PI * fc / fs; val c = cos(w); val a = sin(w) / (2 * 0.7071)
            return Biquad((1 - c) / 2, 1 - c, (1 - c) / 2, 1 + a, -2 * c, 1 - a)
        }
        fun highPass(fc: Double, fs: Double): Biquad {
            val w = 2 * PI * fc / fs; val c = cos(w); val a = sin(w) / (2 * 0.7071)
            return Biquad((1 + c) / 2, -(1 + c), (1 + c) / 2, 1 + a, -2 * c, 1 - a)
        }
    }
}

private class Opened(val rec: AudioRecord, val fs: Int, val fx: List<AudioEffect>) {
    fun release() {
        for (e in fx) try { e.release() } catch (_: Exception) { }
        try { rec.stop() } catch (_: Exception) { }
        try { rec.release() } catch (_: Exception) { }
    }
}

/**
 * Raw AudioRecord loop (16 ms frames). Self-healing: if the mic is taken by another app, goes
 * silent, or errors out, the recorder is released and reopened automatically.
 */
private class PulseEngine(private val ctx: Context) {
    @Volatile private var running = false
    private var thread: Thread? = null

    fun start() {
        if (running) return
        running = true
        thread = Thread({ loop() }, "PulseEngine").also { it.start() }
    }

    fun stop() {
        running = false
        thread?.join(800)
        thread = null
    }

    private fun sleepQuiet(ms: Long) { try { Thread.sleep(ms) } catch (_: InterruptedException) { } }

    private fun loop() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
        while (running) {
            val choice = AccessState.micChoice
            val opened = open(choice)
            if (opened == null) {
                AccessState.setError("Mic start nahi ho raha. Shayad koi aur app mic use kar rahi hai.")
                sleepQuiet(1500)
                continue
            }
            AccessState.setError(null)
            try { process(opened, choice) } catch (_: Exception) { } finally { opened.release() }
            if (running) sleepQuiet(300)
        }
    }

    @SuppressLint("MissingPermission")
    private fun open(choice: Int): Opened? {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val rawOk = am.getProperty(AudioManager.PROPERTY_SUPPORT_AUDIO_SOURCE_UNPROCESSED) == "true"
        val raw = MediaRecorder.AudioSource.UNPROCESSED
        val voice = MediaRecorder.AudioSource.VOICE_RECOGNITION
        val mic = MediaRecorder.AudioSource.MIC
        val sources = when (choice) {
            1 -> listOf(raw, voice, mic)
            2 -> listOf(voice, mic)
            3 -> listOf(mic)
            else -> if (rawOk) listOf(raw, voice, mic) else listOf(voice, mic)
        }
        for (fs in intArrayOf(16000, 44100)) {
            val minBuf = AudioRecord.getMinBufferSize(fs, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            if (minBuf <= 0) continue
            for (src in sources) {
                try {
                    val r = AudioRecord(
                        src, fs, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                        max(minBuf, (fs / 62) * 2 * 8)
                    )
                    if (r.state == AudioRecord.STATE_INITIALIZED) return Opened(r, fs, effectsOff(r))
                    r.release()
                } catch (_: Exception) { }
            }
        }
        return null
    }

    /** Switch off noise suppression / AGC / echo cancel so micro-vibrations are not filtered out. */
    private fun effectsOff(r: AudioRecord): List<AudioEffect> {
        val out = ArrayList<AudioEffect>()
        val sid = r.audioSessionId
        try {
            if (NoiseSuppressor.isAvailable()) NoiseSuppressor.create(sid)?.let { it.setEnabled(false); out.add(it) }
        } catch (_: Exception) { }
        try {
            if (AutomaticGainControl.isAvailable()) AutomaticGainControl.create(sid)?.let { it.setEnabled(false); out.add(it) }
        } catch (_: Exception) { }
        try {
            if (AcousticEchoCanceler.isAvailable()) AcousticEchoCanceler.create(sid)?.let { it.setEnabled(false); out.add(it) }
        } catch (_: Exception) { }
        return out
    }

    private fun process(o: Opened, choice: Int) {
        val rec = o.rec
        val fs = o.fs
        val frame = fs / 62 // ~16 ms
        val hp = Biquad.highPass(15.0, fs.toDouble())
        val lp1 = Biquad.lowPass(150.0, fs.toDouble())
        val lp2 = Biquad.lowPass(150.0, fs.toDouble())
        val pcm = ShortArray(frame)

        var floor = 0f
        var calib = 40
        var inPulse = false
        var pulseStart = 0L
        var lastEnd = 0L
        var count = 0
        var tick = 0
        var silent = 0

        rec.startRecording()
        if (rec.recordingState != AudioRecord.RECORDSTATE_RECORDING) return

        while (running) {
            if (AccessState.micChoice != choice) return // user switched mic source -> reopen
            val n = rec.read(pcm, 0, frame)
            if (n < 0) return // recorder died -> reopen
            if (n == 0) continue

            var peak = 0
            var eLow = 0f
            var eFull = 0f
            for (i in 0 until n) {
                val s = pcm[i].toInt()
                val a = abs(s)
                if (a > peak) peak = a
                val h = hp.process(s / 32768f)
                val l = lp2.process(lp1.process(h))
                eFull += h * h
                eLow += l * l
            }
            if (peak == 0) { if (++silent > 120) return } else silent = 0 // mic silenced by system

            val low = sqrt(eLow / n)
            val full = sqrt(eFull / n)
            val m = when (AccessState.mode) {
                0 -> low
                1 -> full
                else -> low + 0.5f * full
            }

            if (AccessState.recalibrate) { AccessState.recalibrate = false; calib = 40; floor = 0f }
            val sens = AccessState.sensitivity
            val thr = max(floor * (4.5f / sens).coerceAtLeast(1.4f), 0.0012f / sens)
            val now = SystemClock.elapsedRealtime()

            if (calib > 0) {
                floor = if (floor == 0f) m else floor * 0.9f + m * 0.1f
                calib--
            } else {
                if (!inPulse) {
                    floor = floor * 0.97f + min(m, thr) * 0.03f
                } else if (now - pulseStart > 1500) {
                    // sustained noise, not a pulse: adapt to it
                    floor = m; inPulse = false; lastEnd = now
                    count = max(0, count - 1)
                }

                if (!inPulse && m > thr && now - lastEnd > 80) {
                    inPulse = true; pulseStart = now; count++
                } else if (inPulse && m < thr * 0.5f) {
                    inPulse = false; lastEnd = now
                    if (now - pulseStart > 500) count = max(0, count - 1) // too long = speech/noise
                }

                if (count > 0 && !inPulse && now - lastEnd > 420) {
                    val c = min(count, ActionMap.MAX)
                    count = 0
                    AccessState.gesture(c)
                    AccessProperService.instance?.perform(c)
                }
            }
            if (++tick % 2 == 0) AccessState.level(min(1f, m / (thr * 2f)))
        }
    }
}
