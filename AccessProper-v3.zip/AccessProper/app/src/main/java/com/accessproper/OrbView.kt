package com.accessproper

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator
import kotlin.math.min

/** Glowing AI orb. Gradients are built once; per-frame work is just canvas transforms. */
class OrbView @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : View(c, a) {

    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f * resources.displayMetrics.density
    }
    private var cx = 0f; private var cy = 0f; private var r = 0f
    private var breath = 0f; private var level = 0f; private var shown = 0f
    private var ripple = -1f
    private var active = false

    private val breathAnim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2400
        repeatCount = ValueAnimator.INFINITE
        repeatMode = ValueAnimator.REVERSE
        interpolator = AccelerateDecelerateInterpolator()
        addUpdateListener {
            breath = it.animatedValue as Float
            shown += (level - shown) * 0.25f
            invalidate()
        }
    }
    private val rippleAnim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 700
        interpolator = DecelerateInterpolator()
        addUpdateListener { ripple = it.animatedValue as Float }
        addListener(object : android.animation.AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: android.animation.Animator) { ripple = -1f }
        })
    }

    init { setLayerType(LAYER_TYPE_HARDWARE, null) }

    fun setActive(on: Boolean) { active = on; if (!on) level = 0f }
    fun setLevel(l: Float) { level = l.coerceIn(0f, 1f) }
    fun pulse() { rippleAnim.cancel(); rippleAnim.start() }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); breathAnim.start() }
    override fun onDetachedFromWindow() { breathAnim.cancel(); rippleAnim.cancel(); super.onDetachedFromWindow() }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        cx = w / 2f; cy = h / 2f; r = min(w, h) * 0.22f
        glowPaint.shader = RadialGradient(
            cx, cy, r * 2.3f,
            intArrayOf(Color.parseColor("#FF7FB069"), Color.parseColor("#447FB069"), Color.TRANSPARENT),
            floatArrayOf(0.35f, 0.65f, 1f), Shader.TileMode.CLAMP
        )
        corePaint.shader = RadialGradient(
            cx - r * 0.3f, cy - r * 0.3f, r * 1.3f,
            intArrayOf(Color.parseColor("#FFF3F9E8"), Color.parseColor("#FF7FB069"), Color.parseColor("#FF1F3A2B")),
            floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
        )
    }

    override fun onDraw(canvas: Canvas) {
        val scale = 1f + 0.05f * breath + if (active) 0.22f * shown else 0f
        canvas.save()
        canvas.scale(scale, scale, cx, cy)
        glowPaint.alpha = if (active) 255 else 120
        canvas.drawCircle(cx, cy, r * 2.3f, glowPaint)
        canvas.drawCircle(cx, cy, r, corePaint)
        ringPaint.color = if (active) 0xFF00E676.toInt() else 0xFFFF1744.toInt()
        ringPaint.alpha = if (active) 230 else 150
        canvas.drawCircle(cx, cy, r * 1.14f, ringPaint)
        canvas.restore()

        if (ripple >= 0f) {
            ringPaint.color = Color.WHITE
            ringPaint.alpha = ((1f - ripple) * 200).toInt()
            canvas.drawCircle(cx, cy, r * (1.2f + 1.6f * ripple), ringPaint)
        }
    }
}
