package com.accessproper

import android.content.Context
import android.os.Handler
import android.os.Looper

/** Shared state + main-thread event hub between the service and the UI. */
object AccessState {
    interface Listener {
        fun onRunning(running: Boolean)
        fun onLevel(level: Float)
        fun onGesture(count: Int)
        fun onError(message: String?)
    }

    const val DEFAULT_PROGRESS = 60

    @Volatile var running = false
        private set
    @Volatile var error: String? = null
        private set
    @Volatile var listener: Listener? = null
    /** Higher = more sensitive. */
    @Volatile var sensitivity = fromProgress(DEFAULT_PROGRESS)
    /** 0 = chest (low band), 1 = tap/knock (full band), 2 = mixed. */
    @Volatile var mode = 2
    /** 0 = auto, 1 = raw, 2 = voice recognition, 3 = standard mic. */
    @Volatile var micChoice = 0
    @Volatile var recalibrate = false

    private val main = Handler(Looper.getMainLooper())
    private fun prefs(c: Context) =
        c.applicationContext.getSharedPreferences("ap", Context.MODE_PRIVATE)

    fun fromProgress(p: Int): Float = 0.5f + p / 100f * 7.5f

    fun load(c: Context) {
        val p = prefs(c)
        sensitivity = fromProgress(p.getInt("sens", DEFAULT_PROGRESS))
        mode = p.getInt("mode", 2)
        micChoice = p.getInt("mic", 0)
    }

    fun sensProgress(c: Context): Int = prefs(c).getInt("sens", DEFAULT_PROGRESS)
    fun saveSens(c: Context, p: Int) { prefs(c).edit().putInt("sens", p).apply(); sensitivity = fromProgress(p) }
    fun saveMode(c: Context, m: Int) { prefs(c).edit().putInt("mode", m).apply(); mode = m }
    fun saveMic(c: Context, m: Int) { prefs(c).edit().putInt("mic", m).apply(); micChoice = m }

    fun setRunning(value: Boolean) { running = value; main.post { listener?.onRunning(value) } }
    fun setError(msg: String?) { error = msg; main.post { listener?.onError(msg) } }
    fun level(value: Float) { main.post { listener?.onLevel(value) } }
    fun gesture(count: Int) { main.post { listener?.onGesture(count) } }
}
