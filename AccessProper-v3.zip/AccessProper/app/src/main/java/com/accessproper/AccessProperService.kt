package com.accessproper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

class AccessProperService : AccessibilityService() {

    private val main = Handler(Looper.getMainLooper())

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onDestroy() { instance = null; super.onDestroy() }

    /** Runs whatever action is mapped to this pulse count. Safe to call from any thread. */
    fun perform(pulses: Int) {
        main.post {
            when (ActionMap.get(this, pulses)) {
                Act.SCROLL_DOWN -> swipe(0.72f, 0.28f)
                Act.SCROLL_UP -> swipe(0.28f, 0.72f)
                Act.BACK -> performGlobalAction(GLOBAL_ACTION_BACK)
                Act.HOME -> performGlobalAction(GLOBAL_ACTION_HOME)
                Act.RECENTS -> performGlobalAction(GLOBAL_ACTION_RECENTS)
                Act.NOTIFICATIONS -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
                Act.ASSISTANT -> openAssistant()
                Act.TAP -> tapCentre()
                Act.MEDIA -> mediaPlayPause()
                Act.DIALER -> launch(Intent(Intent.ACTION_DIAL))
                Act.LOCK -> if (Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
                Act.SCREENSHOT -> if (Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
                Act.OPEN_APP -> {
                    val pkg = ActionMap.appPackage(this, pulses)
                    val i = if (pkg != null) packageManager.getLaunchIntentForPackage(pkg) else null
                    if (i != null) launch(i)
                }
                Act.NONE -> {}
            }
        }
    }

    private fun launch(i: Intent) {
        try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { }
    }

    private fun openAssistant() {
        try {
            startActivity(Intent(Intent.ACTION_ASSIST).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
            try {
                startActivity(Intent(Intent.ACTION_WEB_SEARCH).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) {
                performGlobalAction(GLOBAL_ACTION_HOME)
            }
        }
    }

    private fun swipe(fromFrac: Float, toFrac: Float) {
        val m = resources.displayMetrics
        val x = m.widthPixels / 2f
        val path = Path().apply {
            moveTo(x, m.heightPixels * fromFrac)
            lineTo(x, m.heightPixels * toFrac)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, 200)
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    private fun tapCentre() {
        val m = resources.displayMetrics
        val x = m.widthPixels / 2f
        val y = m.heightPixels / 2f
        val path = Path().apply { moveTo(x, y); lineTo(x + 1f, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 60)
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    private fun mediaPlayPause() {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE))
    }

    companion object {
        @Volatile var instance: AccessProperService? = null
    }
}
